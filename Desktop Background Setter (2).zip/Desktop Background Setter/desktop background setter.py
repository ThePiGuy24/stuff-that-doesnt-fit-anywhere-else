print("Loading stuff...")
import os, sys
os.chdir("C:\\")
try:
	import pygame
#except ModuleNotFoundError:
#	print("Installing missing packages...")
#	os.system("\""+sys.executable+"\" -m install \""+os.getcwd()+"\\pygame-1.9.4.tar.gz\"")
#	import pygame
#except PermissionError:
#	os.system("\""+sys.executable+"\" -m install \""+os.getcwd()+"\\pygame-1.9.4.tar.gz\" --user")
#	import pygame
except EnvironmentError or ImportError or PermissionError: # or ModuleNotFoundError:
	print("An error has occurred and the required packages could not be installed.")
	os.system("pause")
	quit()
import tkinter as tk
from tkinter import filedialog
print("Setting up...")
pygame.init()
root = tk.Tk()
root.withdraw()
print("Getting image to set as background...")
file_path = filedialog.askopenfilename(title = "Choose new background image...", filetypes = (("Image files", "*.jpg;*.jpeg;*.png;*.gif;*.bmp;*.pcx;*.tga;*.tif;*.lbm;*.pbm;*.pgm;*.ppm;*.xpm"), ("All files", "*.*")))
file_path = file_path.replace("/","\\")
print("Loading background image...")
try:
	background = pygame.image.load("C:\\Users\\"+os.getenv("username")+"\\AppData\\Local\\Temp\\BGInfo.bmp")
	print("Loading and converting new background image...")
	background.blit(pygame.transform.scale(pygame.image.load(file_path), background.get_size()),(0,0))
	print("Saving background image...")
	pygame.image.save(background, "C:\\Users\\"+os.getenv("username")+"\\AppData\\Local\\Temp\\BGInfo.bmp")
	print("Done! Please refresh background by switching then switching back the background image via the \"personalise\" menu.")
except:
	print("An error has occurred and the background image could not be set.")
os.system("pause")