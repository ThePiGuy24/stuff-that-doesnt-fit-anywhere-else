print("Loading stuff...")
import os, sys
try:
	import pygame
except ModuleNotFoundError:
	print("Installing missing packages...")
	os.system("\""+sys.executable+"\" -m install \""+os.getcwd()+"\\pygame-1.9.4.tar.gz\"")
	import pygame
except PermissionError:
	os.system("\""+sys.executable+"\" -m install \""+os.getcwd()+"\\pygame-1.9.4.tar.gz\" --user")
	import pygame
except EnvironmentError or ImportError or PermissionError or ModuleNotFoundError:
	print("An error has occurred and the required packages could not be installed.")
	os.system("pause")
	quit()
import tkinter as tk
from tkinter import filedialog
print("Setting up...")
pygame.init()
root = tk.Tk()
root.withdraw()
print("Getting image to set as background...")
file_path = filedialog.askopenfilename(title = "Choose new background image...", filetypes = (("Image files", "*.jpg;*.jpeg;*.png;*.gif;*.bmp;*.pcx;*.tga;*.tif;*.lbm;*.pbm;*.pgm;*.ppm;*.xpm"), ("All files", "*.*")))
print("Loading background image...")
try:
	background = pygame.image.load(os.getenv("temp")+"\\BGInfo.bmp")
	print("Loading and converting new background image...")
	scale(pygame.image.load(file_path), background.get_size(), DestSurface = background)
	print("Saving background image...")
	pygame.image.save(background, os.getenv("temp")+"\\BGInfo.bmp")
	print("Done! Please refresh background by switching then switching back the background image via the \"personalise\" menu.")
except:
	print("An error has occurred and the background image could not be set.")
os.system("pause")